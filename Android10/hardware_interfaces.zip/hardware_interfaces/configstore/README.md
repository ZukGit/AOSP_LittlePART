Configstore is specifically the configuration for surface flinger. Other configurations go in other packages.
