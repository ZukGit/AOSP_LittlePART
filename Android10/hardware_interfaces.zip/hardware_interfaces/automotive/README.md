## Autmotive HALs ##
---

## Overview: ##

The automotive HAL tree is used by Android Automotive to discover and
operate hardware specific to a car.

The HALs are not (yet) frozen, as the HAL definition is expected to evolve
between Android releases.
